﻿using CollegeSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeSystem.Repositories
{
    public class ExamsRepository
    {
        private readonly CollegeDbContext context;
        public ExamsRepository(CollegeDbContext context)
        {
            context = this.context;
        }
        public List<Exams> GetAllExams()
        {
            return context.Exams.ToList();
        }



        public void AddExams(Exams s)
        {
            context.Exams.Add(s);
            context.SaveChanges();
        }

        public void UpdatExams(Exams s)
        {
            context.Exams.Update(s);
            context.SaveChanges();
        }
        public Exams GetBYIdExams(int numberid)
        {
            return context.Exams.Find(numberid);
        }


        public void DeleteExams(int numberid)
        {
            {
                var Exams = GetBYIdExams(numberid);
                if (Exams != null)

                {
                    context.Exams.Remove(Exams);
                    context.SaveChanges();
                }


            }
        }
        public List<Exams> GetExamsByDate( )
        {
            return context.Exams.Where(d => d.Date == date).tolist();
        }

        public List<Exams> GetExamsByStudent()
        {
          return context.Exams.
        }

    }
}
