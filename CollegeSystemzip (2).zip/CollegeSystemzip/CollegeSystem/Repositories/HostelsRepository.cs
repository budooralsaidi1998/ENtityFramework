﻿using CollegeSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeSystem.Repositories
{
    public class HostelsRepository
    {
        private readonly CollegeDbContext context;

        public HostelsRepository(CollegeDbContext context)
        {
            context = this.context;
        }


        //get all information table
       public List<Hostels> GetAllhostel ()
        {
            return context.Hostels.Include(h=>h.Students).ToList();

        }
        public Hostels GetBYIdhostel(int hostelid)
        {
            return context.Hostels.Find(hostelid);
        }


        public void Addhostel(Hostels h)
        {
            context.Hostels.Add(h);
            context.SaveChanges();
        }

        public void Updathostels(Hostels s)
        {
            context.Hostels.Update(s);
            context.SaveChanges();
        }
      

        public void DeleteStudent(int numberid)
        {
            {
                var hostel = GetBYIdhostel(numberid);
                if (hostel != null)

                {
                    context.Hostels.Remove(hostel);
                    context.SaveChanges();
                }


            }
        }

        public List<Students> Getstudentbycourse()
        {
            return context.Students.Include(s => s.Courses).ToList();
        }

        public List<Hostels> GetHostelsByCity(string City)
        {
            return context.Hostels.Include(s => s.Students).FirstOrDefault(c => c.City == City).t;
        }

        public Hostels CountHostelsWithAvailableSeats()
        {
            {
                return context.Hostels.Where(h => h.No_Of_Seats> 0).Count(); 
            }
        }






    }
}
