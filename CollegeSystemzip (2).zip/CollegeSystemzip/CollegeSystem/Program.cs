﻿

using CollegeSystem.Models;
using CollegeSystem.Repositories;

using Microsoft.EntityFrameworkCore;

namespace CollegeSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            using var contextdb = new CollegeDbContext();
            CoursesRepository courseRepo = new CourseRepository(contextdb);
            DepartmentsRepository deptRepo = new DepartmentsRepository(contextdb);
            ExamsRepository examRepo = new ExamsRepository(contextdb);
            Faculty_MobileRepository FMobileRepo = new Faculty_MobileRepository(contextdb);
            FacultyRepository facultyRepo = new FacultyRepository(contextdb);
            HostelsRepository hostelsRepo = new HostelsRepository(contextdb);
            Student_PhonesRepository stPhoneRepo = new Student_PhonesRepository(contextdb);
            StudentsRepository studentsRepo = new StudentsRepository(contextdb);
            SubjectsRepository subjectsRepo = new SubjectsRepository(contextdb);
        }
    }
}
