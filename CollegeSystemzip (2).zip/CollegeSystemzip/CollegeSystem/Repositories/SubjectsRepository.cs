﻿using CollegeSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeSystem.Repositories
{
    public class SubjectsRepository
    {
        private readonly CollegeDbContext context;
        public SubjectsRepository(CollegeDbContext context)
        {
            context = this.context;
        }
        public List<Subjects> GetAllSubjects()
        {
            return context.Subjects.ToList();
        }



        public void AddSubjects(Subjects s)
        {
            context.Subjects.Add(s);
            context.SaveChanges();
        }

        public void UpdatSubjects(Subjects s)
        {
            context.Subjects.Update(s);
            context.SaveChanges();
        }
        public Subjects GetBYIdSubjects(int numberid)
        {
            return context.Subjects.Find(numberid);
        }


        public void DeleteSubjects(int numberid)
        {
            {
                var Subjects = GetBYIdSubjects(numberid);
                if (Subjects != null)

                {
                    context.Subjects.Remove(Subjects);
                    context.SaveChanges();
                }


            }
        }

        public List<Subjects> GetSubjectsTaughtByFaculty(int idtaough)
        {
            return context.Subjects.Include(s => s.Faculties).FirstOrDefault(i => i.);
        }

        public Subjects CountSubjects()
        {
            return context.Subjects.Count();
        }


    }
}
