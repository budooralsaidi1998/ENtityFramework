﻿using CollegeSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeSystem.Repositories
{
    public class DepartmentsRepository
    {
        private readonly CollegeDbContext context;
        public DepartmentsRepository(CollegeDbContext context)
        {
            context = this.context;
        }
        public List<Departments> GetAllDepartments()
        {
            return context.Departments.ToList();
        }



        public void AddDepartments(Departments s)
        {
            context.Departments.Add(s);
            context.SaveChanges();
        }

        public void UpdatDepartments(Departments s)
        {
            context.Departments.Update(s);
            context.SaveChanges();
        }
        public Departments GetBYIdDepartments(int numberid)
        {
            return context.Departments.Find(numberid);
        }


        public void DeleteDepartments(int numberid)
        {
            {
                var Departments = GetBYIdDepartments(numberid);
                if (Departments != null)

                {
                    context.Departments.Remove(Departments);
                    context.SaveChanges();
                }


            }
        }

        public List<Departments> GetDepartmentsWithCourses()
        {
            return context.Departments.Include( d  => d.Courses ).ToList();
        }


        public List<Departments> GetDepartmentNames() 
            {
             return context.Departments(d => d.DepT_Name).ToList();
            }
    }
}
