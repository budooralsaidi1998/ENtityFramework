﻿using CollegeSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeSystem.Repositories
{

    public class CoursesRepository
    {
        private readonly CollegeDbContext context;
        public CoursesRepository(CollegeDbContext context)
        {
            context = this.context;
        }
        public List<Courses> GetAllCourses()
        {
            return context.Courses.ToList();
        }



        public void AddCourses(Courses s)
        {
            context.Courses.Add(s);
            context.SaveChanges();
        }

        public void UpdatCourses(Courses s)
        {
            context.Courses.Update(s);
            context.SaveChanges();
        }
        public Courses GetBYIdCourses(int numberid)
        {
            return context.Courses.Find(numberid);
        }


        public void DeleteCourses(int numberid)
        {
            {
                var Courses = GetBYIdCourses(numberid);
                if (Courses != null)

                {
                    context.Courses.Remove(Courses);
                    context.SaveChanges();
                }


            }
        }
        public List<Courses> GetCoursesByDepartment(int deid)
        {
            return context.Courses.FirstOrDefault(s =>s.DID==deid).ToList();
        }

        public List<Courses> GetCoursesWithDuration(int d)
        {
            return context.Courses.FirstOrDefault(c => c.Duration == d).ToList(); 
        }
    }
}
