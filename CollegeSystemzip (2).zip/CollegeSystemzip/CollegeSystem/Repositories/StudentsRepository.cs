﻿using CollegeSystem.Models;
using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Query.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollegeSystem.Repositories
{
    public class StudentsRepository
    {
        private readonly CollegeDbContext context;

        public StudentsRepository(CollegeDbContext context)
        {
            context = this.context;
        }


        //get all information table
        public List<Students> GetAllStudent()
        {
            return context.Students.Include(s => s.Hostels).Include(s => s.Courses).ToList();
        }


       
        public void AddStudent(Students s)
        {
            context.Students.Add(s);
            context.SaveChanges();
        }

        public void Updatstudennt(Students s)
        {
            context.Students.Update(s);
            context.SaveChanges();
        } public Students GetBYIdstudent(int numberid)
        {
            return context.Students.Find(numberid);
        }


        public void DeleteStudent(int numberid)
        {
            {
                var student = GetBYIdstudent(numberid);
                if (student != null)

                {
                    context.Students.Remove(student);
                    context.SaveChanges();
                }


            }
        }

        public List<Students> Getstudentbycourse()
        {
          return  context.Students.Include(s => s.Courses).ToList();
        }


        public Students getStudentByHostel(int hostelid)
        {
            return context.Students.FirstOrDefault(s => s.Host_ID == hostelid);
        }
        
        public List<Students> SearchStudents(string name)
        {
            return context.Students.Where(s=>s.FName == name ).ToList();
        }
     
        //public IEnumerable<Students> GetStudentsWithAgeAbove(int age)
        //{
        //    var date = DateOnly..AddYears(-age);
        //    return context.Students.Where(s => s.DOB <= date).ToList();
        //}

        // Paginate student results
        public IEnumerable<Students> PaginateStudents(int pageNumber, int pageSize)
        {
            return context.Students
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }
    }

}
