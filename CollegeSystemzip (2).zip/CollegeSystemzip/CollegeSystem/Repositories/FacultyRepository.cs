﻿using CollegeSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CollegeSystem.Repositories
{
    public class FacultyRepository
    {
        private readonly CollegeDbContext context;
        public FacultyRepository(CollegeDbContext context)
        {
            context = this.context;
        }
        public List<Faculty> GetAllfaculty()
        {
            return context.Faculties.ToList();
        }



        public void Addfaculty(Faculty s)
        {
            context.Faculties.Add(s);
            context.SaveChanges();
        }

        public void UpdatFaculties(Faculty s)
        {
            context.Faculties.Update(s);
            context.SaveChanges();
        }
        public Faculty GetBYIdFaculties(int numberid)
        {
            return context.Faculties.Find(numberid);
        }


        public void DeleteStudent(int numberid)
        {
            {
                var Faculties = GetBYIdFaculties(numberid);
                if (Faculties != null)

                {
                    context.Faculties.Remove(Faculties);
                    context.SaveChanges();
                }


            }
        }

        public List<Faculty> GetFacultyByDepartment()
        {
            return context.Faculties.Include(f => f.Departments).ToList();
        }

        public List<Faculty> GetFacultyByMobileNumber(int numphone)
        {
            return context.Faculties.Include( f => f.Faculty_Mobiles).Where( c=> c.).ToList();
        }

        public Faculty CalculateAverageSalary()
        {
           
                return context.Faculties.Average(f => f.Salary);
            
        }

    }
}
